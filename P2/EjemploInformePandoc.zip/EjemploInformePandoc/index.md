---
title: Ejemplo de informe
author:
    - Antonio <afgs@ucm.es>
    - Otro <otro@ejemplo.com>

documentclass: scrreport
papersize: a4
lang: es
babel-lang: spanish
---

# Introducción

Este es un informe de ejemplo para ver cómo usar markdown.

El informe está dividido en dos: `index.md` y `content.md`. Para compilarlo,
ejecutar `pandoc index.md content.md -o informe.pdf`.
