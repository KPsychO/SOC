# Conjuntos de datos

Conjuntos de datos para la práctica 2 de Análisis de Redes Sociales.

## Contenidos

- `elon_tweets_2012-2022.csv`: Tuits realizados por Elon Musk entre el año 2012
    y el 2022.
- `avengers_endgame.csv`: Tuits realizados sobre la premier de la película
    "Avengers: Endgame".
- `cyberpunk.csv`: Tuits sobre el videojuego "CyberPunk".

## Uso

Se omiten las fuentes para evitar tentaciones. **Conjunto de datos para
exclusivo uso docente**, se prohíbe terminantemente su distribución.
